from django.contrib import admin
from .models import myuser,Intake
# Register your models here.
admin.site.register(myuser)
admin.site.register(Intake)
